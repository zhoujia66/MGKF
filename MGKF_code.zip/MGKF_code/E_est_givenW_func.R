
### Compute the thresholds and obtain E_est 

# input: 'W': feature statistic matrix
#        'q': nominal FDR level
# output: 'E_est': estimated edge set

##########################################################
threnew<-function(W,q){
  p=dim(W)[1]
  Mmax=floor((q*(p-1))/(2*1.93)-1)
  
  for (j in Mmax:0) {
    NV=j
    ratio=NULL
    ratio1=NULL
    ti=NULL
    Ne=NULL
    Omegahatfinal=matrix(rep(0,p*p),p,p)
    Omegahat=matrix(rep(0,p*p),p,p)
    for (k in 1:p) {
      sortwi=sort(W[k,])
      sortwiabs=sort(abs(W[k,]))
      if(NV==0){
        Wk=sortwi[1]
        kedu=which(sortwiabs>abs(Wk))[1]
        ti[k]=sortwiabs[kedu]
      }else{
        ti[k]=-(sortwi[NV])}
      edghat=which(W[k,]>=ti[k])
      Ne[k]=length(which(W[k,]>=ti[k]))
      Omegahat[k,edghat]=1
    }
    Omegahat=t(Omegahat)+Omegahat
    sumne=length(which(Omegahat!=0))/2
    
    for (i in 1:p){
      ratio[i]=(length(which(W[i,]<=(-ti[i])))+1)/sumne
      ratio1[i]=(length(which(W[i,]<=(-ti[i])))+0.01)/sumne
    }
    A=which(ratio>1/(1.93*p)*q)
    B=which(ratio1>1/(102*p)*q)
    if(length(A)==0|length(B)==0){
      Omegahatfinal=Omegahat
      break;}
  }
  E_est<- (Omegahatfinal != 0 )+0
  return(E_est)
}
