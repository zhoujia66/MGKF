#The code for the simulation study 1 of the revised manuscript with k=9.
#For simulation study 2, we just need to adjust the corresponding parameter settings on this basis.  

library(knockoff)
library(Matrix)
library(mvtnorm)
library(HGSL)

setwd("D:/MGKF_code")
source("graphicalgenerate.R")
source("Generate_knockoff_func.R")
source("isee_all.R")
source("FdrPowerGraphFunc.R")
source("E_est_givenW_func.R")





set.seed(123)
n = 200          # number of observations
p = 100
q = 0.2           # nominal FDR level


k= 9                   # number of graphs

p_block <- 20         # number of variables in each cluster
num_block <- 5
prob = 1             #The probability that a non-diagonal element is not equal to 0
range = c(0.3,0.8)   #Range of values for non-diagonal elements
add_minEigen <- 0.3
signs <- "Random"   #The sign of the value of a non-diagonal element, which can be take "positive", "Negative" and "Random".
permut <- sample(1:p, replace=FALSE)

Result1 <-  Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega1 <- Result1[[1]]
Sigma1 <- Result1[[2]]

Result2 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega2 <- Result2[[1]]
Sigma2 <- Result2[[2]]


Result3 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega3 <- Result3[[1]]
Sigma3 <- Result3[[2]]

Result4 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega4 <- Result4[[1]]
Sigma4 <- Result4[[2]]


Result5 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega5 <- Result5[[1]]
Sigma5 <- Result5[[2]]
mu = rep(0,p)


Result6 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega6 <- Result6[[1]]
Sigma6 <- Result6[[2]]

Result7 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega7 <- Result7[[1]]
Sigma7 <- Result7[[2]]


Result8 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega8 <- Result8[[1]]
Sigma8 <- Result8[[2]]

Result9 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega9 <- Result9[[1]]
Sigma9 <- Result9[[2]]



FDP=NULL
POW=NULL


for (iter in 1:10) {
  X1 <- rmvnorm(n, mu, Sigma1)
  X2<-rmvnorm(n,mu,Sigma2)
  X3<-rmvnorm(n,mu,Sigma3)
  X4<-rmvnorm(n,mu,Sigma4)
  X5<-rmvnorm(n,mu,Sigma5)
  X6<-rmvnorm(n,mu,Sigma6)
  X7<-rmvnorm(n,mu,Sigma7)
  X8<-rmvnorm(n,mu,Sigma8)
  X9<-rmvnorm(n,mu,Sigma9)
  
  
  
  WWW=NULL
  WWWS=NULL
  for (index in 1:p) {
    y1=X1[,index]
    y2=X2[,index]
    y3=X3[,index]
    y4=X4[,index]
    y5=X5[,index]
    y6=X6[,index]
    y7=X7[,index]
    y8=X8[,index]
    y9=X9[,index]
    
    x1=X1[,-index]
    x2=X2[,-index]
    x3=X3[,-index]
    x4=X4[,-index]
    x5=X5[,-index]
    x6=X6[,-index]
    x7=X7[,-index]
    x8=X8[,-index]
    x9=X9[,-index]
   
    x1k=Creatknockoffs(x1,mu[-index],method = "asdp")
    x2k=Creatknockoffs(x2,mu[-index],method = "asdp")
    x3k=Creatknockoffs(x3,mu[-index],method = "asdp")
    x4k=Creatknockoffs(x4,mu[-index],method = "asdp")
    x5k=Creatknockoffs(x5,mu[-index],method = "asdp")
    x6k=Creatknockoffs(x6,mu[-index],method = "asdp")
    x7k=Creatknockoffs(x7,mu[-index],method = "asdp")
    x8k=Creatknockoffs(x8,mu[-index],method = "asdp")
    x9k=Creatknockoffs(x9,mu[-index],method = "asdp")
    p1=dim(x1)[2]
    yy=c(y1,y2,y3,y4,y5,y6,y7,y8,y9)
    
    
    
    xxau1=cbind(x1,x1k)
    xxau2=cbind(x2,x2k)
    xxau3=cbind(x3,x3k)
    xxau4=cbind(x4,x4k)
    xxau5=cbind(x5,x5k)
    xxau6=cbind(x6,x6k)
    xxau7=cbind(x7,x7k)
    xxau8=cbind(x8,x8k)
    xxau9=cbind(x9,x9k)
    
    
    
    
    #######HGSL
    xxaudiag=as.matrix(bdiag(xxau1,xxau2,xxau3,xxau4,xxau5,xxau6,xxau7,xxau8,xxau9))
    grps <- rep(1:(2*(p-1)), 9)
    lambdas <- seq(2,10,2)*sqrt((k+2*log(p)+2*sqrt(k*log(p)))/n)
    indexn <- c(1, n, n+1, 2*n, 2*n+1,3*n,3*n+1,4*n,4*n+1,5*n,5*n+1,6*n,6*n+1,7*n,7*n+1,8*n,8*n+1,9*n)
    betahgsl=S_TISP_Path(xxaudiag,yy,grps,k=9,index = indexn,lambdas = lambdas)
    
    
    RSS=NULL
    AIC=NULL
    for (i in 1:length(lambdas)) {
      RSS[i]=t(yy-xxaudiag%*%betahgsl[,i])%*%(yy-xxaudiag%*%betahgsl[,i])
      AIC[i]=length(yy)*log(RSS[i]/(length(yy)))+2*length(which(betahgsl[,i]!=0))
    }
    
    bestid=which.min(AIC)
    w1=betahgsl[,bestid]
    
  
    W=NULL
    for (i in 1:p1) {
      Co=c(w1[i],w1[i+(2*p1)],w1[i+(4*p1)],w1[i+(6*p1)],w1[i+(8*p1)],w1[i+(10*p1)],w1[i+(12*p1)],w1[i+(14*p1)],w1[i+(16*p1)])
      Ck=c(w1[i+p1],w1[i+(3*p1)],w1[i+(5*p1)],w1[i+(7*p1)],w1[i+(9*p1)],w1[i+(11*p1)],w1[i+(13*p1)],w1[i+(15*p1)],w1[i+(17*p1)])
      W[i]=norm(Co,"2")-norm(Ck,"2")
    }
    
    
    WW=append(W,0,index-1)
    WWW=rbind(WWW,WW)
  }
  
  
  
  Omegasum=Omega1+Omega2+Omega3+Omega4+Omega5+Omega6+Omega7+Omega8+Omega9
  
  E_estfdr1<- threnew(WWW,q) 
  zuizhongfdr1=Fdp_Power_Graph_func(E_estfdr1, Omegasum)
  FDP[iter]=zuizhongfdr1[1]
  POW[iter]=zuizhongfdr1[2]
  
  
  
  print(c(iter,FDP[iter],POW[iter]))
}


mean(FDP)
mean(POW)
