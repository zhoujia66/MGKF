#The code for the simulation study 1 of the revised manuscript with k=3.
#For simulation study 2, we just need to adjust the corresponding parameter settings on this basis.  

library(knockoff)
library(Matrix)
library(mvtnorm)
library(HGSL)

setwd("D:/MGKF_code")
source("graphicalgenerate.R")
source("Generate_knockoff_func.R")
source("isee_all.R")
source("FdrPowerGraphFunc.R")
source("E_est_givenW_func.R")





set.seed(123)
n = 400          # number of observations
p = 200
q = 0.2           # nominal FDR level


k= 3                   # number of graphs

p_block <- 20         # number of variables in each cluster
num_block <- 10
prob = 1             #The probability that a non-diagonal element is not equal to 0
range = c(0.3,0.8)   #Range of values for non-diagonal elements
add_minEigen <- 0.3
signs <- "Random"   #The sign of the value of a non-diagonal element, which can be take "positive", "Negative" and "Random".
permut <- sample(1:p, replace=FALSE)

Result1 <-  Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega1 <- Result1[[1]]
Sigma1 <- Result1[[2]]

Result2 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega2 <- Result2[[1]]
Sigma2 <- Result2[[2]]


Result3 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega3 <- Result3[[1]]
Sigma3 <- Result3[[2]]


mu = rep(0,p)



FDP=NULL
POW=NULL


for (iter in 1:50) {
  
  ##Generate data
  
  X1 <- rmvnorm(n, mu, Sigma1)
  X2<-rmvnorm(n,mu,Sigma2)
  X3<-rmvnorm(n,mu,Sigma3)
  
#Multiple graphical knockoff procedure
  
  WWW=NULL
  WWWS=NULL
  for (index in 1:p) {
    y1=X1[,index]
    y2=X2[,index]
    y3=X3[,index]
    
    
    
    x1=X1[,-index]
    x2=X2[,-index]
    x3=X3[,-index]
    
    
  
    x1k=Creatknockoffs(x1,mu[-index],method = "asdp")
    x2k=Creatknockoffs(x2,mu[-index],method = "asdp")
    x3k=Creatknockoffs(x3,mu[-index],method = "asdp")
    
    
    p1=dim(x1)[2]
    yy=c(y1,y2,y3)
    
    
    
    xxau1=cbind(x1,x1k)
    xxau2=cbind(x2,x2k)
    xxau3=cbind(x3,x3k)
    
  
    
    #######HGSL
    xxaudiag=as.matrix(bdiag(xxau1,xxau2,xxau3))
    grps <- rep(1:(2*(p-1)), 3)
    lambdas <- seq(2,10,2)*sqrt((k+2*log(p)+2*sqrt(k*log(p)))/n)
    indexn <- c(1, n, n+1, 2*n, 2*n+1,3*n)
    betahgsl=S_TISP_Path(xxaudiag,yy,grps,k=3,index = indexn,lambdas = lambdas)
    
    
    RSS=NULL
    AIC=NULL
    for (i in 1:length(lambdas)) {
      RSS[i]=t(yy-xxaudiag%*%betahgsl[,i])%*%(yy-xxaudiag%*%betahgsl[,i])
      AIC[i]=length(yy)*log(RSS[i]/(length(yy)))+2*length(which(betahgsl[,i]!=0))
    }
    
    bestid=which.min(AIC)
    w1=betahgsl[,bestid]
    
  
    
    
    W=NULL
    for (i in 1:p1) {
      Co=c(w1[i],w1[i+(2*p1)],w1[i+(4*p1)])
      Ck=c(w1[i+p1],w1[i+(3*p1)],w1[i+(5*p1)])
      W[i]=norm(Co,"2")-norm(Ck,"2")
    }
    
    
    WW=append(W,0,index-1)
    WWW=rbind(WWW,WW)
  }
  
  
  
  Omegasum=Omega1+Omega2+Omega3
  

  
  E_estfdr1<- threnew(WWW,q) 
  E_estfdr1<-( (t(E_estfdr1)+E_estfdr1) != 0 )+0
  zuizhongfdr1=Fdp_Power_Graph_func(E_estfdr1, Omegasum)
  FDP[iter]=zuizhongfdr1[1]
  POW[iter]=zuizhongfdr1[2]
  
  print(c(iter,FDP[iter],POW[iter]))
}
 
mean(FDP)
mean(POW)

