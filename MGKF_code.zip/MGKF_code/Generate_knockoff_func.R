##Generate knockoffs
Creatknockoffs<-function(X, mu, method = c("asdp", "sdp", "equi"), diag_s = NULL){
  hatter1=isee(X,regfactor = "log",npermu =5,sis.use = 0,bia.cor = 1);
  Omehat1=hatter1$Omega.isee.c
  Sigma=solve(Omehat1)
  #Sigma=(Sigma+t(Sigma))/2
  method = match.arg(method)
  if ((nrow(Sigma) <= 500) && method == "asdp") {
    method = "sdp"
  }
  if (is.null(diag_s)) {
    diag_s = diag(switch(match.arg(method), equi = create.solve_equi(Sigma), 
                         sdp = create.solve_sdp(Sigma), asdp = create.solve_asdp(Sigma)))
  }
  if (is.null(dim(diag_s))) {
    diag_s = diag(diag_s, length(diag_s))
  }
  if (all(diag_s == 0)) {
    warning("The conditional knockoff covariance matrix is not positive definite. Knockoffs will have no power.")
    return(X)
  }
  #SigmaInv_s = solve(Sigma, diag_s)
  mu_k = X - sweep(X, 2, mu, "-") %*% Omehat1%*%diag_s
  Sigma_k = 2 * diag_s - diag_s %*% Omehat1%*%diag_s
  X_k = mu_k + matrix(rnorm(ncol(X) * nrow(X)), nrow(X)) %*% chol(Sigma_k)
  return(X_k)
}
###



