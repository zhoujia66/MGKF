### Obtain the related response vector, standardized (column length 1) design matrix and the knockoff matrix of the linear model by treating each node as response

# input: 'X': data matrix (n \times p)
#        'knockoff_method': choose from ("equi" and "sdo"), method to construct knockoffs
#        'num.cores': number of cores used for the parallel
# output: 'Nodewise_Y_Xs_Xk_list': a list of response vector 'Y', standardized design matrix 'Xs' and knockoff matrix 'Xk'

##########################################################

# library(knockoff)
# library(parallel)      

##########################################################
### Main function:
Nodewise_Y_Xs_Xk <- function(X, mu,Sigma,knockoff_method, num.cores){
  
  Nodewise_Y_Xs_Xk_list <- mcmapply(OneNode_func, 1:ncol(X), MoreArgs=list(X,mu,Sigma, knockoff_method), mc.cores=num.cores)
  return(Nodewise_Y_Xs_Xk_list)
}

### Sub-function: Treat one node as response 
### Return response vector, standardized design matrix and knockoff matrix
OneNode_func <- function(node_index, X, mu,Sigma,knockoff_method){
  
  X_design <- X[, -node_index]
  Y <- X[,node_index]
  
  Omegahat=solve(Sigma)
  betau=solve(t(Y)%*%Y)%*%t(Y)%*%X_design
  uhat=t(betau)
  vhat=var(Y)
  Ahat=Omegahat[-node_index,-node_index];
  Bhat=Omegahat[-node_index,node_index];
  weight=1/(1-vhat*betau%*%Bhat)
  Omegahat1=Ahat- weight[1]*vhat*(Bhat%*%t(Bhat))
  sigmahat1=solve(Omegahat1)
  
  # if(min(eigen(sigmahat1)$value) < 1e-2)
  # {
  #   pdsigmahat1=maxproj.cov(mat=sigmahat1, epsilon=1e-2)
  # }else
  # {
  #   pdsigmahat1=sigmahat1 
  # }
  X_Xk <- create.gaussian(X_design, mu[-node_index], sigmahat1 , method=knockoff_method)   # function from "knockoff" package
  Xs <- X_design
  Xk <- X_Xk
  
  return(list(Y, Xs, Xk))
}
