
library(mvtnorm)     # generate multivariate Gaussian date
library(glmnet)
setwd("~/HGKF")
source("OtherFuncs/Graphs.R")
source("OtherFuncs/FdrPowerGraphFunc.R")

source("GGMknockoffFilter/Nodewise_Y_Xs_Xk.R")
source("GGMknockoffFilter/Z_max_lambda.R")
source("GGMknockoffFilter/Z_coef.R")
source("GGMknockoffFilter/Z_stat_func_list_ElasticNet.R")
source("GGMknockoffFilter/E_est_givenW_func.R")
source("GGMknockoffFilter/GKF_Re.R")
source("GGMknockoffFilter/isee_all.R")



t1=Sys.time()

set.seed(123)

n = 200        # number of observations
p = 100
q = 0.2           # nominal FDR level

### ER graph


p_block <- 20          # number of variables in each cluster
num_block <- 5
prob = 1
range = c(0.3,0.8)
add_minEigen <- 0.3
signs <- "Random"  
permut <- sample(1:p, replace=FALSE)

Result1 <-  Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs, permut)
Omega1 <- Result1[[1]]
Sigma1 <- Result1[[2]]
# 
Result2 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs, permut)
Omega2 <- Result2[[1]]
Sigma2 <- Result2[[2]]

Result3 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega3 <- Result3[[1]]
Sigma3 <- Result3[[2]]

Result4 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega4 <- Result4[[1]]
Sigma4 <- Result4[[2]]


Result5 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega5 <- Result5[[1]]
Sigma5 <- Result5[[2]]


Result6 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega6 <- Result6[[1]]
Sigma6 <- Result6[[2]]

Result7 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega7 <- Result7[[1]]
Sigma7 <- Result7[[2]]

Result8 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega8 <- Result8[[1]]
Sigma8 <- Result8[[2]]

Result9 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega9 <- Result9[[1]]
Sigma9 <- Result9[[2]]


Omega=abs(Omega1)+abs(Omega2)+abs(Omega3)+abs(Omega4)+abs(Omega5)+abs(Omega6)+abs(Omega7)+abs(Omega8)+abs(Omega9)

mu = rep(0,p)



FDP=NULL
POW=NULL





for (iter in 1:20) {
  X1 <- rmvnorm(n, mu, Sigma1)
  X2<-rmvnorm(n,mu,Sigma2)
  X3<-rmvnorm(n,mu,Sigma3)
  X4<-rmvnorm(n,mu,Sigma4)
  X5<-rmvnorm(n,mu,Sigma5)
  X6<-rmvnorm(n,mu,Sigma6)
  X7<-rmvnorm(n,mu,Sigma7)
  X8<-rmvnorm(n,mu,Sigma8)
  X9<-rmvnorm(n,mu,Sigma9)
  
  Xwhole=rbind(X1,X2,X3,X4,X5,X6,X7,X8,X9) 
  
  
  hatter=isee(Xwhole,regfactor = "log",npermu =5,sis.use = 0,bia.cor = 1);
  Omegahat=hatter$Omega.isee.c
  Sigmahat=solve(Omegahat)
  
  E_est <- GKF_Re( Xwhole, mu, Sigmahat, q, num.cores=2)
  results=Fdp_Power_Graph_func(E_est, Omega)
  print(results)
  FDP[iter]=results[[1]]
  POW[iter]=results[[2]]
  
  
}

t2=Sys.time()
t=t2-t1
mean(FDP)
mean(POW)
t



