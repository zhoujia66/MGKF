
library(mvtnorm)     # generate multivariate Gaussian date
library(glmnet)
setwd("~/HGKF")
source("OtherFuncs/Graphs.R")
source("OtherFuncs/FdrPowerGraphFunc.R")

source("GGMknockoffFilter/Nodewise_Y_Xs_Xk.R")
source("GGMknockoffFilter/Z_max_lambda.R")
source("GGMknockoffFilter/Z_coef.R")
source("GGMknockoffFilter/Z_stat_func_list_ElasticNet.R")
source("GGMknockoffFilter/E_est_givenW_func.R")
source("GGMknockoffFilter/GKF_Re.R")
source("GGMknockoffFilter/isee_all.R")





set.seed(123)
n = 500          # number of observations
p = 200
q = 0.2           # nominal FDR level

### ER graph
k= 3

p_block <- 20           # number of variables in each cluster
num_block <- 10
prob = 1
range = c(0.3,0.8)
add_minEigen <- 0.3
signs <- "Random"  
permut <- sample(1:p, replace=FALSE)

Result1 <-  Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega1 <- Result1[[1]]
Sigma1 <- Result1[[2]]

Result2 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega2 <- Result2[[1]]
Sigma2 <- Result2[[2]]


Result3 <- Cluster_ER_graph(num_block, p_block, prob, range, add_minEigen, signs,permut)
Omega3 <- Result3[[1]]
Sigma3 <- Result3[[2]]


mu = rep(0,p)



FDP=NULL
POW=NULL

for (iter in 1:20) {
  X1 <- rmvnorm(n, mu, Sigma1)
  X2<-rmvnorm(n,mu,Sigma1)
  X3<-rmvnorm(n,mu,Sigma1)

  Xwhole=rbind(X1,X2,X3) 
  
  
  hatter=isee(Xwhole,regfactor = "log",npermu =5,sis.use = 0,bia.cor = 1);
  Omegahat=hatter$Omega.isee.c
  Sigmahat=solve(Omegahat)

  E_est <- GKF_Re( Xwhole, mu, Sigmahat, q, num.cores=2)
  Omega=abs(Omega1)+abs(Omega2)+abs(Omega3)
  results=Fdp_Power_Graph_func(E_est, Omega)
  print(results)
  FDP[iter]=results[[1]]
  POW[iter]=results[[2]]
  
 
}


mean(FDP)
mean(POW)




